"""Temporary ranker override, only when the explicitly selected q8 library is set."""
import ctypes
import os
import weakref
from time import perf_counter_ns

lib_path = os.environ.get("HPIS_Q8_PROBE")
if lib_path:
    import numpy as np
    from cryptography.exceptions import InvalidTag
    from integration.mapped_index import native
    lib = ctypes.CDLL(lib_path)
    pointer = ctypes.c_void_p
    lib.coarse_prepare.argtypes = [pointer,ctypes.c_int,ctypes.c_int]
    lib.coarse_prepare.restype = pointer
    lib.coarse_free.argtypes = [pointer]
    q8 = lib.hpis_rank_q8
    q8.argtypes = native.load_library().argtypes + [pointer,pointer]
    q8.restype = ctypes.c_int

    def rank(fn,image,unit,rotated,k,key):
        secure = image.sealed is not None
        if secure and (not isinstance(key, bytes) or len(key) != 32):
            raise PermissionError("256-bit vector key required")
        projection = rotated if secure else unit
        if not hasattr(image,"_coarse_holder"):
            handle = lib.coarse_prepare(image.native_data_ptr, image.size, image.dim)
            if not handle:
                raise RuntimeError("coarse index allocation failed")
            image._coarse_holder = handle
            weakref.finalize(image,lib.coarse_free,handle)
        t0=perf_counter_ns()
        scores=np.empty(image.size,dtype=np.float32)
        result=np.empty(k,dtype='<i8')
        opened=(ctypes.c_int64*2)()
        margin=image.fp_slack if secure else 8*image.dim*np.finfo(np.float32).eps
        code=q8(image.size,image.dim,k,scores.ctypes.data,image.native_ids_ptr,
                image.native_data_ptr,image.sealed_ptr if secure else None,key,unit.ctypes.data,
                *image.native_controls,image.radius if secure else margin,margin,result.ctypes.data,
                ctypes.addressof(opened),image._coarse_holder,projection.ctypes.data)
        if code:
            raise InvalidTag("invalid ciphertext or query")
        image.diagnostic={"gemv_us":0.,"select_us":(perf_counter_ns()-t0)/1000.,
                          "exact_evaluations":opened[0],"data_alignment":image.native_data_ptr%64,
                          "query_alignment":projection.ctypes.data%64,"coarse":"Q8/fused"}
        if opened[1]:
            resolved,extra=image.resolve_ties(unit,rotated,k,key)
            return resolved,extra+(opened[0] if secure else 0)
        return result.tolist(),opened[0] if secure else 0

    native.rank=rank
