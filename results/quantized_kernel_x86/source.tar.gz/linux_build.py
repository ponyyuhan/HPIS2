"""Build the optional q8 fused ranker and the unmodified reference for comparison."""
import os,shlex,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
repo=Path(os.environ.get("HPIS_REPO", ".")).resolve()
cc=os.environ.get("CC","cc"); cxx=os.environ.get("CXX","c++")
crypto=shlex.split(subprocess.check_output(["pkg-config","--cflags","--libs","libcrypto"],text=True))
cflags=[a for a in crypto if a.startswith("-I")]
target=["-O3","-std=c++17","-fPIC","-march=native","-fno-math-errno"]
def run(command):
 subprocess.run(command,cwd=p,check=True)
run([cxx,*target,"-c","coarse_simd.cc","-o","coarse.o"])
run([cc,"-O3","-std=c11","-fPIC","-march=native","-ffp-contract=off",*cflags,"-c","rank_fused.c","-o","rankq.o"])
run([cxx,"-shared","rankq.o","coarse.o",*crypto,"-lm","-o","fused.so"])
subprocess.run([sys.executable,"-m","integration.mapped_index.build_native","--output",str(p/"baseline.so")],cwd=repo,check=True)
