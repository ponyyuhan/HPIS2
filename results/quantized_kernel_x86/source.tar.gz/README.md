Temporary HPIS exact-ranker microbenchmark for existing test hosts.

From the HPIS2 checkout, put these files in /tmp/hpis-coarse-kernel on the host:
coarse_simd.cc, rank_fused.c, linux_build.py, bench_fused.py. The .c was generated from the project's hpis_rank implementation with the independent early screen below. This adds no disk/schema/wire artifacts. Only the public-to-HPIC sketch has a temporary int8 memory copy.

    export HPIS_REPO="$PWD"
    export COARSE_DIR=/tmp/hpis-coarse-kernel
    export BASELINE_LIB="$COARSE_DIR/baseline.so"
    export GLOVE=/path/to/glove-100-angular.hdf5
    python "$COARSE_DIR/linux_build.py"
    PYTHONPATH="$PWD" OPENBLAS_NUM_THREADS=1 python "$COARSE_DIR/bench_fused.py"

All input matrix rows and queries must be finite, dim <=4096, and from the current normalized/plain or RAP setup. Required implementations are ARMv8 dot-product or AVX2, with a scalar fallback for functional verification. The Python test applies the same optimized coarse selector/ranker to plain and encrypted inputs, verifies the ordered IDs against the baseline native ranker for 512 queries per mode, and prints both timing distributions. Build using the existing test host's compiler and libcrypto. For integrated diagnosis, load the fused shared library, attach coarse_prepare() once per mapped image, then call hpis_rank_q8() in place of the BLAS call and hpis_rank() combination. hpis_rank_q8 extends hpis_rank's ABI with two trailing pointers: the prepared object and the actual float32 scoring query (unit query for plain, qR for encrypted). The scores array remains caller-provided scratch; it is populated by hpis_rank_q8. Free coarse_free() when the mapped image is released. If opened[1] requests exact rational tie resolution, use the original MappedImage.resolve_ties.

For true database sketch x, query q and their quantized reconstructions x' and q', Cauchy–Schwarz gives

    |x.q - x'.q'| <= ||x-x'||_2 ||q||_2 + ||x'||_2 ||q-q'||_2.

A small dimensional floating-point allowance covers f32 requantization/dot rounding. The metadata is computed from the existing f32 sketches/plain rows only. Each int8 all-row estimate produces arbitrary valid seeds. The current code opens those k rows before deriving the true score cutoff. We can therefore discard any row where estimated_dot + numerical_bound + original_RAP_radius < cutoff. At all remaining rows we recompute the FP32 sketch dot and apply the original native cap bound, exact distance and authenticated AES-GCM logic. Near ties still resolve through the existing exact-order fallback. Input integers are in [-127,127] per database row and [-63,63] per query. On AVX2 a row byte is shifted to [1,255]; even the largest pair in VPMADDUBSW is <=2*255*63=32130. Exact accumulated int32 products for <=4096 coordinates also fit.

A temporary optional full-pipeline override is supplied in activate/sitecustomize.py. From the repository root, use PYTHONPATH=$COARSE_DIR/activate:$PWD HPIS_MAPPED_NATIVE=$COARSE_DIR/baseline.so HPIS_Q8_PROBE=$COARSE_DIR/fused.so with the normal integration.mapped_index.bench CLI. Identical Q8 acceleration applies to plain and encrypted snapshots. The library precomputes only the first time a particular immutable snapshot is loaded, with automatic release when it is replaced. Its select_us measures the entire fused stage and gemv_us is zero (not separately timed).
