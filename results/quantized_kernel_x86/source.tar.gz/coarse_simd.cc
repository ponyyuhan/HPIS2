#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <vector>
#include <functional>
#if defined(__aarch64__) && defined(__ARM_FEATURE_DOTPROD)
#include <arm_neon.h>
#elif defined(__AVX2__)
#include <immintrin.h>
#endif

constexpr int B=32;

struct Prep {
    int n,d,m;
    std::vector<int8_t> weights;
    std::vector<float> scales, errors, norms;
    double max_error=0, max_norm=0;
    Prep(const float *x,int n_,int d_): n(n_),d(d_),m((d+3)/4),weights((n+B-1)/B*B*m*4,0),scales(n,0),errors(n),norms(n) {
        for (int i=0;i<n;i++) {
            const float *r=x+(size_t)i*d;
            double mx=0,e2=0,n2=0;
            for(int j=0;j<d;j++) mx=std::max(mx,(double)std::abs(r[j]));
            float sc=(float)(mx/127.);
            scales[i]=sc;
            for(int j=0;j<d;j++){
                int a=sc ? (int)std::nearbyint((double)r[j]/sc):0;
                a=std::max(-127,std::min(127,a));
                double delta=(double)r[j]-(double)a*sc;
                e2+=delta*delta; n2+=(double)a*sc*(double)a*sc;
                const size_t idx=((size_t)(i/B)*m*B+(size_t)(j/4)*B+i%B)*4+j%4;
#if defined(__AVX2__)
                ((uint8_t*)weights.data())[idx]=(uint8_t)(a+128);
#else
                weights[idx]=(int8_t)a;
#endif
            }
            const double err=std::sqrt(e2),norm=std::sqrt(n2);
            errors[i]=std::nextafter((float)err,INFINITY); norms[i]=std::nextafter((float)norm,INFINITY);
            max_error=std::max(max_error,(double)errors[i]);max_norm=std::max(max_norm,(double)norms[i]);
        }
    }
};

extern "C" void* coarse_prepare(const float *x,int n,int d){
    if(!x||n<1||d<1||d>4096) return nullptr;
    try {return new Prep(x,n,d);} catch(...){return nullptr;}
}
extern "C" void coarse_free(void *p){ delete (Prep*)p; }

inline void intdots(int n,int m,const int8_t *w,const int8_t *q,int qsum,const float *ss,float qs,float *out){
    int32_t local[B];
    for (int i=0;i<n;i+=B,w+=(size_t)m*B*4){
#if defined(__aarch64__) && defined(__ARM_FEATURE_DOTPROD)
        int32x4_t acc[B/4]={};
        for(int t=0;t<m;t++){
            int32_t qq; memcpy(&qq,q+t*4,4);
            auto v=vreinterpretq_s8_s32(vdupq_n_s32(qq));
            const int8_t *row=w+t*B*4;
            for(int z=0;z<B/4;z++) acc[z]=vdotq_s32(acc[z],vld1q_s8(row+16*z),v);
        }
        for(int z=0;z<B/4;z++) vst1q_s32(local+4*z,acc[z]);
#elif defined(__AVX2__)
        __m256i acc[B/8]={};
        const auto ones=_mm256_set1_epi16(1);
        for(int t=0;t<m;t++){
            int32_t qq; memcpy(&qq,q+t*4,4);
            const auto v=_mm256_set1_epi32(qq);
            const int8_t *row=w+t*B*4;
            for(int z=0;z<B/8;z++){
                const auto bytes=_mm256_loadu_si256((const __m256i*)(row+32*z));
                const auto pairs=_mm256_maddubs_epi16(bytes,v);
                acc[z]=_mm256_add_epi32(acc[z], _mm256_madd_epi16(pairs,ones));
            }
        }
        for(int z=0;z<B/8;z++) _mm256_storeu_si256((__m256i*)(local+8*z),_mm256_sub_epi32(acc[z],_mm256_set1_epi32(128*qsum)));
#else
        std::fill(local,local+B,0);
        for(int t=0;t<m;t++)for(int z=0;z<B;z++)for(int j=0;j<4;j++)local[z]+=(int)w[(t*B+z)*4+j]*(int)q[t*4+j];
#endif
        int lim=std::min(B,n-i);
        for(int z=0;z<lim;z++) out[i+z]=(float)local[z]*ss[i+z]*qs;
    }
}

extern "C" double coarse_approx(void *ptr,const float *q,float *scores){
    const auto& a=*(Prep*)ptr;
    alignas(32) int8_t qb[4096]={};
    double mx=0,eq=0,nq=0; int qsum=0;
    for(int j=0;j<a.d;j++) mx=std::max(mx,(double)std::abs(q[j]));
    if(mx==0||!std::isfinite(mx))return -1;
    const float qs=(float)(mx/63.);
    for(int j=0;j<a.d;j++){
        int v=std::max(-63,std::min(63,(int)std::nearbyint((double)q[j]/qs)));
        qb[j]=(int8_t)v; qsum+=v;
        const double diff=(double)q[j]-(double)v*qs; eq+=diff*diff; nq+=(double)q[j]*q[j];
    }
    eq=sqrt(eq); nq=sqrt(nq);
    intdots(a.n,a.m,a.weights.data(),qb,qsum,a.scales.data(),qs,scores);

    const double rounding=(8+a.d)*std::numeric_limits<float>::epsilon()*(1+a.max_norm)*(1+nq);
    return a.max_error*nq+a.max_norm*eq+rounding;
}
